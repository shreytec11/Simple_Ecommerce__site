from django.contrib import admin

from .models import DeliveryOptions

admin.site.register(DeliveryOptions)
